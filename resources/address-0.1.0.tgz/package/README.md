# klt-address

`klt-address` is the address-input package repo for Kultera applications.

It is being developed as a separate package that will be used alongside `klt-ui`, not as a second standalone design system. The current focus is `AddressInput`: a bare-control address autocomplete component with Google Places integration, a normalized address payload, and a migration path toward `klt-ui` package consumption.

## Package Direction

The intended long-term model is:

- `klt-ui` owns the shared design-system foundation
- `klt-address` owns address-specific components and provider integration
- applications install both packages side by side

See [docs/agents/tandem-package-boundary.md](docs/agents/tandem-package-boundary.md) for the current boundary definition.

## Current Status

This repo is still in active package bootstrapping.

Available today:

- `AddressInput` component implementation
- `AddressInputProvider` for app-level API-key configuration
- provider acquisition utility for Google Places
- normalized `AddressValue` contract
- `@klt-ui/design-system` peer dependency for shared tokens and theme context
- React peer dependency metadata for consuming apps
- Vitest and Testing Library behavior coverage
- maintainer docs and Context Records for the workstream

Not finalized yet:

- Storybook or long-term visual fixture strategy
- first successful Azure pipeline publish
- lockfile refresh against the Azure Artifacts feed after replacing the local `@klt-ui/design-system` link with the published package dependency
- final runtime contract for changing the `AddressInput` `apiKey` after Google has already initialized
- final provider-compliance guidance beyond the standing requirement that provider-facing behavior must remain EULA and terms compliant

## Development

Requirements:

- Node.js compatible with the repo toolchain
- pnpm 10.28.0
- `@klt-ui/design-system` available from the Kultera Azure Artifacts feed
- React and ReactDOM compatible with the package peer range, currently `>=18.2.0 <20`

Local note: after authenticating to the Kultera Azure Artifacts feed, run `pnpm install` so `@klt-ui/design-system` resolves from the published feed package instead of a stale local link.

Install dependencies:

```bash
pnpm install
```

Start the local demo app:

```bash
pnpm dev
```

Run the local demo app with committed fixture data instead of a Google API key:

```powershell
$env:VITE_ADDRESS_DEMO_MODE="true"
pnpm dev
```

`VITE_ADDRESS_DEMO_MODE` only affects the local demo shell. In consuming apps, use `AddressInputProvider demoMode` explicitly when a no-secret prototype host such as Figma Make needs local fixture suggestions.

Run lint:

```bash
pnpm run lint
```

Run tests:

```bash
pnpm run test
```

Check context records:

```bash
pnpm context:lint
pnpm context:remind
```

Build the package:

```bash
pnpm run build
```

Build the local demo app into `dist-demo`:

```bash
pnpm run build:demo
```

## Public Surface

The package entrypoint is:

- `@klt-ui/address`

Current intended public exports:

- `AddressInput`
- `AddressInputProvider`
- `AddressInputProps`
- `AddressInputSize`
- `AddressInputValidationState`
- `AddressInputWidth`
- `AddressInputProviderProps`
- `AddressComponent`
- `AddressValue`
- `AddressAutocompleteProvider`
- `AddressAutocompleteRequest`
- `AddressAutocompleteSelection`
- `AddressAutocompleteSuggestion`

Internal hooks and provider normalization utilities are not part of the root package API. Consumers should not import from deep internal paths.

The package also exposes `@klt-ui/address/prototype` for no-secret prototype helpers:

- `createStaticAddressAutocompleteProvider`
- `suffolkCountyAddressAutocompleteProvider`
- `suffolkCountyAddressFixtures`

This prototype entrypoint uses committed local fixture data and does not call Faker or Google.

Provider precedence is:

1. explicit `autocompleteProvider`
2. effective Google `apiKey`
3. provider-level `demoMode` fixture provider
4. plain input fallback

That means missing API keys still produce plain input behavior unless the app deliberately supplies an autocomplete provider or enables `demoMode`.

The package build emits JavaScript, declaration files, and component CSS under `dist/`. Until the final `klt-ui` CSS-loading contract is settled, consumers should treat `@klt-ui/address/style.css` as the address-package stylesheet and keep the broader foundation-style setup provisional.

`react` and `react-dom` are peer dependencies. Consuming apps provide their own React runtime; this package keeps dev copies only for the local demo, tests, and build.

`@klt-ui/design-system` is also a peer dependency. Consuming apps must install it and load the design-system token files before the address package stylesheet:

```tsx
import '@klt-ui/design-system/tokens/css/default-light.css'
import '@klt-ui/design-system/tokens/css/default-dark.css'
import '@klt-ui/design-system/tokens/css/default-hc.css'
import '@klt-ui/design-system/tokens/css/kultera-light.css'
import '@klt-ui/design-system/tokens/css/kultera-dark.css'
import '@klt-ui/design-system/tokens/css/kultera-hc.css'
import '@klt-ui/design-system/tokens/css/le-light.css'
import '@klt-ui/design-system/tokens/css/le-dark.css'
import '@klt-ui/design-system/tokens/css/le-hc.css'
import '@klt-ui/address/style.css'
```

Apps already importing `@klt-ui/design-system/styles.css` for full design-system component usage may continue to do so; the required contract for `klt-address` itself is that the default token CSS and each app-supported brand token CSS are loaded before `@klt-ui/address/style.css`. `klt-address` should remain brand-agnostic and consume any brand that `klt-ui` exposes through its semantic tokens.

Wrap the app with `ThemeProvider` so the document receives the required `data-brand`, `data-theme`, `data-density`, and `data-klt-motion` attributes:

```tsx
import { ThemeProvider } from '@klt-ui/design-system'

export function AppProviders({ children }: { children: React.ReactNode }) {
  return (
    <ThemeProvider brand="kultera" theme="light" density="cozy" motion="on">
      {children}
    </ThemeProvider>
  )
}
```

The consuming app owns Google API-key sourcing. In application code, read the key from that app's configuration and pass it into the package:

```tsx
import { AddressInput, AddressInputProvider } from '@klt-ui/address'

export function App() {
  return (
    <AddressInputProvider apiKey={import.meta.env.VITE_GOOGLE_API_KEY}>
      <AddressInput name="address" autoComplete="street-address" />
    </AddressInputProvider>
  )
}
```

`AddressInput apiKey` is still available as an instance-level override, but the package must not bundle a Google API key or read a repo-owned environment variable as library behavior. Until the runtime key-switching contract is settled, treat the key as stable for the lifetime of the app session.

For no-secret prototype hosts, the same production component can use committed local fixtures:

```tsx
import { AddressInput, AddressInputProvider } from '@klt-ui/address'
import { suffolkCountyAddressAutocompleteProvider } from '@klt-ui/address/prototype'

export function PrototypeAddressForm() {
  return (
    <AddressInputProvider autocompleteProvider={suffolkCountyAddressAutocompleteProvider}>
      <AddressInput name="address" autoComplete="street-address" />
    </AddressInputProvider>
  )
}
```

For a smaller no-secret switch, use `demoMode` only when no provider or API key is configured:

```tsx
<AddressInputProvider demoMode>
  <AddressInput name="address" autoComplete="street-address" />
</AddressInputProvider>
```

`@klt-ui/address` is configured to publish version `0.1.0` to the Kultera Azure Artifacts npm feed used by `@klt-ui/design-system`. The CSS-loading contract is explicit: apps load the required `@klt-ui/design-system` token files for their supported brands, then load `@klt-ui/address/style.css`. Kultera and LE are current examples; future brands should work through the same `klt-ui` token and `ThemeProvider` path without address-package changes.

Provider-facing behavior must also remain compliant with applicable provider EULAs and terms. Do not harden behavior around attribution, display, caching, persisted data, coordinates, API-key handling, or request patterns without checking the active provider requirements and recording any relevant compliance note in the workstream docs.

## Repo Structure

- `src/components/inputs/AddressInput/` - component implementation, tests, and planning docs
- `src/lib/google/` - Google Places loader utility
- `src/themes/` - legacy temporary local foundation aliases kept only until unused bootstrap files are removed
- `docs/agents/` - maintainer-facing workflow, Context Records, and package-boundary notes

## Working Docs

Key maintainer docs:

- [AddressInput usage guide](docs/usage/address-input.md)
- [AddressInput bootstrap guide](docs/agents/address-input-bootstrap-guide.md)
- [Tandem package boundary](docs/agents/tandem-package-boundary.md)
- [Context Records README](docs/agents/context/README.md)
- [AddressInput implementation guide](src/components/inputs/AddressInput/IMPLEMENTATION_GUIDE.md)
- [AddressInput evaluation](src/components/inputs/AddressInput/EVALUATION.md)
- [AddressInput roadmap](src/components/inputs/AddressInput/ROADMAP.md)
- [AddressInput knockout list](src/components/inputs/AddressInput/KNOCKOUT_LIST.md)
- [AddressInput prototype provider plan](src/components/inputs/AddressInput/PROTOTYPE_PROVIDER_PLAN.md)

## Contributing

When making architectural or behavioral changes:

- update the relevant component-local docs
- update the current Context Record
- keep the package boundary with `klt-ui` explicit
- avoid introducing a parallel token or styling language in this repo

When changing styling:

- keep component styles expressed in `@klt-ui/design-system` semantic tokens
- do not add new global token families to this repo
- keep app/demo styling separate from component contract decisions

If a change affects the relationship between `klt-address` and `klt-ui`, update [docs/agents/tandem-package-boundary.md](docs/agents/tandem-package-boundary.md) in the same session.
