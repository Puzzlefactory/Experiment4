# @klt-ui/composition

AppFrame is the golden-path composition component for Kultera UI. It wraps content in the
canonical ThemeProvider from `@klt-ui/design-system` and uses `useThemePreference` for
preference state. AppearanceSettings is the compact, site-facing settings block for theme
and density controls. ThemeSwitcher remains a lightweight settings panel for broader theme
scaffolding. ResponsiveHeaderBar is the approved responsive app-header composition built on
the HeaderBar primitive. FooterComposition provides an opinionated wrapper around FooterBar for
common shell chrome.

AppFrame also exposes `useAppFrame()` for shared shell preference access and
`useAppFrameOverlayRoot()` for shell-level portal targeting from composition descendants.

Guardrails:

- No site-specific logic (no routes, nav items, auth, APIs, or product strings).
- ThemeProvider and `useThemePreference` live in `@klt-ui/design-system` and remain canonical.
- SSR safe by default: no browser globals at module scope or during render.
- Browser-only behavior must run after mount, and renders must be deterministic by props.

Import:

```tsx
import {
  AppFrame,
  AppearanceSettings,
  FooterComposition,
  ResponsiveHeaderBar,
  ThemeSwitcher,
  useAppFrame,
  useAppFrameOverlayRoot,
} from '@klt-ui/composition'
import { useThemePreference } from '@klt-ui/design-system'
```

Example:

```tsx
import { AppFrame, AppearanceSettings } from '@klt-ui/composition'
import { Container, Page, useThemePreference } from '@klt-ui/design-system'

export function App() {
  const preference = useThemePreference()

  return (
    <AppFrame theme={preference.resolvedTheme} brand="kultera" density={preference.density}>
      <Page>
        <Container size="lg">
          <AppearanceSettings preference={preference}>
            <p>Changes here propagate through the same site-level preference controller.</p>
          </AppearanceSettings>
        </Container>
      </Page>
    </AppFrame>
  )
}
```

For site-level settings, keep the site brand owned by the shell and let `AppearanceSettings`
manage only theme and density. If you initialize your own `useThemePreference` controller, seed
its `defaultBrand` with the active site brand so a local settings panel does not accidentally
switch the shell onto an unloaded brand token sheet.

For detailed AppFrame guidance, including shell ownership boundaries and hook usage patterns, see
`packages/composition/src/AppFrame/README.md` in the repository.
