# Kultera UI (`@klt-ui/design-system`)

Kultera UI is a React component library with tokenized theming, Storybook documentation, and automation for metadata/manifest generation.

## Requirements

- Node `>=24.13.0`
- pnpm `10.28.0` (via Corepack)

## Quick start

```bash
corepack enable
corepack prepare pnpm@10.28.0 --activate
pnpm install

# playground app
pnpm dev

# Storybook docs
pnpm storybook
```

## Optional container workflow

This repo now includes a repo-owned container definition:

- [Dockerfile](./Dockerfile) pins the Linux dev image to Node `24.13.0` on Debian Bookworm and prepares `pnpm 10.28.0`.
- [.devcontainer/devcontainer.json](./.devcontainer/devcontainer.json) points VS Code Dev Containers at that Dockerfile instead of a managed image family.
- The image also installs the `codex` and `claude` CLIs; the devcontainer recommends the GitHub Copilot and GitHub Copilot Chat VS Code extensions in the remote environment.

Use it when you want a known-good Linux environment that stays under repo control:

1. Start Docker Desktop.
2. Open the repo folder in VS Code.
3. Do not start with `Open Workspace from File`; use the folder-based flow for the first container launch.
4. Run `Dev Containers: Rebuild and Reopen in Container`.
5. Wait for the post-create step to run `pnpm install`.

Once attached, run the usual commands from the container terminal:

```bash
pnpm dev
pnpm storybook
pnpm test
pnpm run ci:all
```

Ports `5173` and `6006` are forwarded automatically for Vite and Storybook.

Quick verification inside the container:

```bash
node -v
pnpm -v
codex --version
claude --version
pwd
```

Expected:

- Node `v24.13.0`
- pnpm `10.28.0`
- a working `codex` and `claude` binary
- a path under `/workspaces/...`

`pnpm install` now bootstraps the repo's local git hooks automatically. If a fresh clone,
Windows checkout, or rebuilt container ever stops running `pre-commit`/`pre-push`, run
`pnpm run hooks:install` once in the repo root.

## Daily development flow

1. `pnpm lint`
2. `pnpm typecheck`
3. `pnpm test`
4. `pnpm run meta:generate` after prop/token/style changes
5. `pnpm run meta:ensure` from a clean/staged state

When you want a full local preflight, run:

```bash
pnpm run ci:all
```

The `pre-push` hook runs that same command for branch pushes when local hooks are installed.

## Build and packaging

- `pnpm build` - build tokens/docs/library/types into `dist/`.
- `pnpm build:all` - build design system + composition package.
- `pnpm run pack:all` - create package tarballs in `artifacts/`.
- `pnpm build-storybook` - produce static Storybook output in `storybook-static/`.

## Release builds and publishing

Release/publish runs are controlled by Azure DevOps pipeline parameters in [azure-pipelines.yml](./azure-pipelines.yml).

Short version:

- Run the pipeline manually when doing release actions.
- Choose `releaseStage`: `none`, `beta`, or `prod`.
- Toggle publish/deploy flags (`publishToAzureArtifacts`, `publishToFigmaRegistry`, `deployStorybookProd`, `deployStorybookDev`) as needed.
- `prod` requires a stable `v*` tag on a commit reachable from `master`.
- `beta` allows branch runs or prerelease tags.

Full runbook: [docs/release-build.md](./docs/release-build.md).

## Docs map

- [docs/consumer/index.md](./docs/consumer/index.md) - consumer docs entry point
- [docs/consumer/usage.md](./docs/consumer/usage.md) - consumer setup, theming, layout guidance, and metadata entrypoints
- [docs/consumer/components.md](./docs/consumer/components.md) - generated offline component reference
- [STYLING_GUIDELINES.md](./STYLING_GUIDELINES.md) - maintainer CSS organization rules
- [AGENTS.md](./AGENTS.md) - repository guardrails and working contract for agents

## Package usage

```bash
pnpm add @klt-ui/design-system
```

Import base styles first, then brand token CSS that matches your `ThemeProvider` brand/theme usage:

```tsx
import '@klt-ui/design-system/styles.css'
import '@klt-ui/design-system/tokens/css/kultera-light.css'
import '@klt-ui/design-system/tokens/css/kultera-dark.css'
import '@klt-ui/design-system/tokens/css/kultera-hc.css'
```

```tsx
import { ThemeProvider } from '@klt-ui/design-system'

export function App({ children }: { children: React.ReactNode }) {
  return (
    <ThemeProvider brand="kultera" theme="light" density="cozy" motion="on">
      {children}
    </ThemeProvider>
  )
}
```

## Project layout

- `src/components/` - components and primitives
- `src/stories/` - Storybook stories and interaction scenarios
- `tokens/` - token sources
- `src/themes/` - theme CSS artifacts
- `docs/` - usage, metadata, ADRs, and agent guidance
- `scripts/` - build/docs/metadata/token automation
