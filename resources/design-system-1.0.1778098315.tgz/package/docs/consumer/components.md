# Component catalog

This catalog is generated from `component.meta.json` files.
For programmatic access, see [usage.md#machine-readable-outputs](usage.md#machine-readable-outputs).

Storybook: https://kultera-storybook-prod-atdza8erh0hcc7cj.eastus-01.azurewebsites.net/

## Data display

| Component     | Description                                                                                      | Status | Tier |
| ------------- | ------------------------------------------------------------------------------------------------ | ------ | ---- |
| Avatar        | Token-driven avatar with image fallback, optional presence badge, and a companion group pattern. | stable | 1    |
| KulteraLockup | Kultera logo lockup with optional "Powered by" caption.                                          | stable | 1    |

## Feedback

| Component | Description                                                                | Status | Tier |
| --------- | -------------------------------------------------------------------------- | ------ | ---- |
| Badge     | Compact status badge with semantic variants and optional outline.          | stable | 1    |
| Modal     | Token-driven dialog primitive that wraps Radix with a simpler Kultera API. | stable | 1    |
| Progress  | Tokenized progress indicator with optional labels.                         | stable | 1    |
| Toast     | Managed toast system with queueing, swipe gestures, and tokenized styling. | stable | 2    |

## Inputs

| Component       | Description                                                                                                                                  | Status | Tier |
| --------------- | -------------------------------------------------------------------------------------------------------------------------------------------- | ------ | ---- |
| Button          | Token-driven button with intent, appearance, and size axes.                                                                                  | stable | 1    |
| Checkbox        | Opinionated checkbox field with integrated label, helper text, validation messaging, and visual intents.                                     | stable | 1    |
| DatePicker      | Single-date picker built on DayPicker with a tokenized popover trigger.                                                                      | stable | 2    |
| DateRangePicker | Range picker with month/year dropdowns and an internal DayPicker popover.                                                                    | stable | 2    |
| Field           | Shared label + helper + validation wrapper that aligns any input control.                                                                    | stable | 1    |
| Input           | Tokenized text input control with optional icons, size/width variants, and validation states.                                                | stable | 1    |
| Label           | Field label wrapper with helper/validation messaging and inline or stacked layouts.                                                          | stable | 1    |
| RadioGroup      | Opinionated radio group that bundles labels, helper text, validation, and Radix-powered keyboard interactions.                               | stable | 1    |
| Select          | Opinionated dropdown that renders labels, helper text, and validation messaging through FieldFrame without wiring Radix primitives directly. | stable | 1    |
| Slider          | Range slider with tokenized track and thumb sizing.                                                                                          | stable | 2    |
| Switch          | Opinionated toggle switch with built-in label, helper text, and validation messaging.                                                        | stable | 1    |
| Toggle          | On/off toggle button with a normalized boolean-control API.                                                                                  | stable | 2    |
| ToggleGroup     | Segmented control that bundles labels, helper text, validation messaging, and Radix-powered toggle behavior.                                 | stable | 2    |

## Layout

| Component     | Description                                                                                                                                                | Status | Tier |
| ------------- | ---------------------------------------------------------------------------------------------------------------------------------------------------------- | ------ | ---- |
| Accordion     | Single or multiple expansion accordion with token-driven styling and Radix-powered motion.                                                                 | stable | 1    |
| AppShell      | Viewport-level shell that arranges optional header, sidebar, main, and footer regions in a grid with configurable scroll behavior.                         | stable | 1    |
| AspectRatio   | Thin primitive for maintaining a fixed aspect ratio around media or overlay content.                                                                       | stable | 2    |
| Bleed         | Tier-2 escape-hatch helper that lets child content break out of local container padding along the x, y, or both axes using tokenized offsets.              | stable | 2    |
| Canvas        | Anchoring region that provides a relative positioning context for overlays and absolutely positioned children.                                             | stable | 2    |
| Card          | Structured surface with header, content, and footer slots.                                                                                                 | stable | 1    |
| Collapsible   | Tokenized collapsible panel with semantic intent, appearance, and size for the header block and animated body content.                                     | stable | 2    |
| Container     | Centers content and constrains width using design-system tokens. Applies consistent horizontal gutter and configurable vertical padding.                   | stable | 1    |
| Cover         | Tier-2 layout primitive that vertically centers content with optional top and bottom clamps for hero sections.                                             | stable | 2    |
| Divider       | Layout-aware separator that maps spacing, orientation, and border styling to shared tokens.                                                                | stable | 3    |
| Fieldset      | Semantic wrapper for grouping form controls with a legend, helper copy, and action row.                                                                    | stable | 2    |
| FooterBar     | Footer layout that balances metadata, navigation links, and trailing actions.                                                                              | stable | 2    |
| FormLayout    | Container-owned form grid wrapper that aligns form controls across shared columns and provides a dedicated actions row.                                    | stable | 2    |
| Frame         | Aspect-ratio wrapper that keeps media on the design token grid with alignment and rounding controls.                                                       | stable | 3    |
| Grid          | Tier-1 layout primitive for multi-column compositions with token-controlled gaps and optional auto-fit behaviour.                                          | stable | 1    |
| HeaderBar     | Responsive header layout with brand, navigation, and action slots.                                                                                         | stable | 2    |
| Inline        | Tier-1 horizontal layout primitive for arranging items, grouped actions, and wrap-friendly collections with token-driven spacing, alignment, and wrapping. | stable | 1    |
| Page          | Semantic page wrapper with header/body/footer slots for composition within AppShell.                                                                       | stable | 1    |
| Panel         | Lightweight bounded surface for sections, toolbars, and callouts that do not need Card slot structure.                                                     | stable | 2    |
| Reel          | Tier-2 layout primitive for horizontally scrollable, snap-aligned strips driven by tokenized gaps and item widths.                                         | stable | 2    |
| ScrollArea    | Primitive-tier scroll region namespace with tokenized surface and scrollbar styling.                                                                       | stable | 2    |
| Separator     | Semantic separator supporting horizontal and vertical orientations.                                                                                        | stable | 1    |
| Sidebar       | Tier-2 layout primitive that pairs a fixed-width pane with fluid content, ideal for navigation, filter panels, or summary sidebars.                        | stable | 2    |
| Spacer        | Flex spacing utility that absorbs leftover room in Stack or Inline layouts using token scales.                                                             | stable | 3    |
| Stack         | Tier-1 layout primitive that provides vertical rhythm with token-controlled gaps and alignment.                                                            | stable | 1    |
| Switcher      | Tier-2 layout primitive that arranges items in responsive rows using a tokenized minimum item width.                                                       | stable | 2    |
| ThemeProvider | Sets brand, theme, and density data attributes on the document root so tokens resolve consistently.                                                        | stable | 1    |

## Navigation

| Component | Description                                                                                              | Status | Tier |
| --------- | -------------------------------------------------------------------------------------------------------- | ------ | ---- |
| Menubar   | Primitive-tier desktop menubar namespace with tokenized menu and submenu styling.                        | stable | 3    |
| NavLinks  | Tokenized navigation links wrapper with current-state styling and router-friendly custom link rendering. | stable | 2    |
| Tabs      | Tokenized tabs wrapper with a data-driven API and optional primitive escape hatches.                     | stable | 1    |

## Overlay

| Component     | Description                                                                                | Status | Tier |
| ------------- | ------------------------------------------------------------------------------------------ | ------ | ---- |
| ContextMenu   | Right-click context menu with a wrapped trigger and item-array API.                        | stable | 2    |
| Drawer        | Docked overlay that hugs a container edge with optional scrim and full-height alignment.   | stable | 2    |
| DropdownMenu  | Structured dropdown menu with a wrapped trigger and item-array API.                        | stable | 2    |
| FloatingPanel | Anchored overlay panel that can collapse into a compact toggle.                            | stable | 2    |
| HoverCard     | Deferred hover preview with a wrapped trigger and content API.                             | stable | 2    |
| Popover       | Wrapped popover surface with a trigger/content API and optional primitive escape hatches.  | stable | 1    |
| Tooltip       | Accessible hover/focus tooltip with a single wrapped Kultera API and token-driven styling. | stable | 1    |

## Status

| Component | Description                                                     | Status | Tier |
| --------- | --------------------------------------------------------------- | ------ | ---- |
| Skeleton  | Tokenized skeleton placeholder with optional shimmer animation. | stable | 2    |
| Spinner   | Tokenized loading spinner for async states.                     | stable | 2    |
