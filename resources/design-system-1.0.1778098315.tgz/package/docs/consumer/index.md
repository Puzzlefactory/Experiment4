# @klt-ui/design-system docs

## Start here

- [Usage guide](usage.md) for installation, CSS imports, theming, motion, layout patterns, customization, and machine-readable outputs.
- [Component catalog](components.md) for the generated offline component reference.

## Component discovery

- Storybook: https://kultera-storybook-prod-atdza8erh0hcc7cj.eastus-01.azurewebsites.net/
- Offline catalog: [components.md](components.md)

## Metadata and tokens

- Machine-readable outputs are documented in [usage.md#machine-readable-outputs](usage.md#machine-readable-outputs).
- [Token reference index](../../dist/docs/tokens.md) exported as `@klt-ui/design-system/docs/tokens`
- [Foundation tokens](../../dist/docs/reference-foundation.md) exported as `@klt-ui/design-system/docs/tokens/reference-foundation.md`
- [Semantic tokens](../../dist/docs/reference-semantic.md) exported as `@klt-ui/design-system/docs/tokens/reference-semantic.md`
