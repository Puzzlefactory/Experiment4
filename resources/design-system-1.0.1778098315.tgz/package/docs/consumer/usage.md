# Kultera UI usage guide

## Install

```bash
pnpm add @klt-ui/design-system react react-dom
```

## Required CSS

Import `styles.css` first to load the shared base theme, then import the brand token files that
match the `ThemeProvider` brand and theme modes you intend to support.

```tsx
import '@klt-ui/design-system/styles.css'
import '@klt-ui/design-system/tokens/css/kultera-light.css'
import '@klt-ui/design-system/tokens/css/kultera-dark.css'
import '@klt-ui/design-system/tokens/css/kultera-hc.css'
```

If your app only supports one theme mode, import only that mode's brand file after `styles.css`.

## Font setup

The design system does not set a base `font-family`. Load your app fonts separately and set
`font-family` on `:root` or `body` before rendering components.

## Component discovery

- Storybook: https://kultera-storybook-prod-atdza8erh0hcc7cj.eastus-01.azurewebsites.net/
- Offline catalog: [components.md](components.md)

## ThemeProvider

Use `ThemeProvider` near your app root so the document root receives the correct
`data-brand`, `data-theme`, `data-density`, and `data-klt-motion` attributes.

```tsx
import { ThemeProvider } from '@klt-ui/design-system'

export function AppProviders({ children }: { children: React.ReactNode }) {
  return (
    <ThemeProvider brand="kultera" theme="light" density="cozy" motion="on">
      {children}
    </ThemeProvider>
  )
}
```

### ThemeProvider props

- `brand`: `"default" | "kultera" | "le" | "verizon"` with string overrides allowed for future brands
- `theme`: `"light" | "dark" | "hc"`
- `density`: `"compact" | "cozy" | "roomy"`
- `motion`: `"on" | "off"`

Set `motion="off"` when you want token-driven motion durations to resolve to `0ms`.

### Available token files

The package publishes brand and mode token files under `@klt-ui/design-system/tokens/css/`:

- `default-light.css`, `default-dark.css`, `default-hc.css`
- `kultera-light.css`, `kultera-dark.css`, `kultera-hc.css`
- `le-light.css`, `le-dark.css`, `le-hc.css`
- `verizon-light.css`, `verizon-dark.css`, `verizon-hc.css`

## Breakpoints

`useBreakpoint` is deprecated. It remains available for existing consumers during the transition,
but new code should prefer CSS-first responsive patterns, local container queries, and explicit
layout primitives instead of JS viewport listeners.

If your app still needs breakpoint-specific behavior, keep that logic local to the app surface and
avoid using the design system helper as the default approach.

If you also need CSS media queries, prefer `@custom-media` in your app build pipeline instead of
embedding raw breakpoint values throughout component styles.

## Layout conventions

- Use `Container` for width and gutters.
- Use `Stack` for vertical flow and `Inline` for horizontal flow.
- Use `Canvas` when you need a local overlay anchor.
- Use `Modal` for dialog-style flows instead of wiring Radix dialog primitives directly.
- Avoid margins for layout spacing; use token-driven gaps and padding instead.

## AppShell and Page

`AppShell` is the viewport-level scaffold. It can render optional header, sidebar, and footer
regions, and it keeps `main` as the scroll container by default.

- `layout="holy-grail"`: header + main + footer
- `layout="header-main"`: header + main
- `layout="content-only"`: main only
- `scroll="main"`: main region scrolls
- `scroll="page"`: the full shell scrolls

```tsx
import { AppShell, Container, HeaderBar, Page, Stack, ThemeProvider } from '@klt-ui/design-system'

const navigation = [
  { href: '/overview', label: 'Overview', current: true },
  { href: '/reports', label: 'Reports' },
]

export function App() {
  return (
    <ThemeProvider brand="kultera" theme="light" density="cozy" motion="on">
      <AppShell
        layout="header-main"
        header={<HeaderBar brand={<strong>Kultera</strong>} links={navigation} sticky elevated />}
      >
        <Page>
          <Page.Body>
            <Container>
              <Stack gap="lg">
                <h1>Overview</h1>
                <p>Latest activity and KPIs.</p>
              </Stack>
            </Container>
          </Page.Body>
        </Page>
      </AppShell>
    </ThemeProvider>
  )
}
```

### Page semantics

- `Page` defaults to `as="section"`.
- Use `as="main"` only when the page is the document main landmark.
- When `as="main"`, provide a descriptive `ariaLabel`.
- `Page.Header`, `Page.Body`, and `Page.Footer` override the `header` and `footer` props when both are used.

### Sidebar composition

Use `Sidebar` when the page body needs a fixed side rail plus a fluid content area.

```tsx
import { Container, Page, Sidebar, Stack } from '@klt-ui/design-system'
;<Page>
  <Page.Body>
    <Container>
      <Sidebar
        basis="20rem"
        sidebar={
          <Stack gap="sm">
            <a href="/cases">Cases</a>
            <a href="/reports">Reports</a>
          </Stack>
        }
      >
        <Stack gap="md">
          <h2>Case list</h2>
          <p>Review active cases and triage the queue.</p>
        </Stack>
      </Sidebar>
    </Container>
  </Page.Body>
</Page>
```

## React Router integration

```tsx
import { Link } from 'react-router-dom'
import type { HeaderBarLinkComponentProps } from '@klt-ui/design-system'

const HeaderNavLink = ({ href, label, className, current }: HeaderBarLinkComponentProps) => (
  <Link to={href ?? '/'} className={className} aria-current={current ? 'page' : undefined}>
    {label}
  </Link>
)

<HeaderBar links={navigation} linkComponent={HeaderNavLink} />
```

## Customization

Use semantic tokens instead of raw values.

- Colors: `--color-surface-1`, `--color-text-primary`, `--color-action-primary`
- Spacing: `--space-gap-sm`, `--space-pad-md`, `--space-padv-xs`
- Typography: `--font-size-sm-scaled`, `--font-weight-medium`, `--font-line-height-body`
- Borders: `--border-rule-default`, `--color-border-default`

Apply app-level overrides after the base styles and brand token imports.

```css
:root {
  --color-surface-1: var(--color-surface-2);
  --space-gap-md: var(--space-gap-lg);
}
```

For app-specific variants, define component-scoped variables with your own prefix and derive them
from existing design tokens.

```css
.AppCard {
  --app-card-surface: var(--color-surface-2);
  --app-card-shadow: var(--shadow-2);
}
```

Do not invent new global token families in app CSS.

## Machine-readable outputs

These package exports are the recommended entrypoints for AI tooling, docs tooling, and component
discovery workflows:

- `@klt-ui/design-system/design-system.manifest.json`
  - Top-level index of components, props, guarantees, accessibility notes, and tokens used.
- `@klt-ui/design-system/meta/components.json`
  - Aggregated output of every `component.meta.json` file.
- `@klt-ui/design-system/docs/tokens`
  - Generated token reference index.
- `@klt-ui/design-system/docs/tokens/reference-foundation.md`
  - Foundation token reference.
- `@klt-ui/design-system/docs/tokens/reference-semantic.md`
  - Semantic token reference.

Treat the JSON metadata files as generated artifacts. Update component sources and rerun the
metadata scripts instead of editing the JSON directly.
